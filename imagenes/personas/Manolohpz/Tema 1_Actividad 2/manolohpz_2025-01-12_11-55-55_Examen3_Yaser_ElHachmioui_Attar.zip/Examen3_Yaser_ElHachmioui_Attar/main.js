window.onload = function main() {

    var object1;
    var object2;
    const button = document.getElementById("start");

    fetch("http://localhost:5050/api/ruta1")
        .then(response => {
            return response.json();
        })
        .then(response => {
            setTimeout(() => {
                console.log("Primera api consumida.");
                var object1 = response;
                localStorage.setItem("object1", JSON.stringify(object1));
            }, 1000);
            return fetch("http://localhost:5050/api/ruta2");
        })
        .then(response => {
            return response.json();
        })
        .then(response => {
            setTimeout(() => {
                console.log("Segunda api consumida.");
                var object2 = response;
                localStorage.setItem("object2", JSON.stringify(object2));
            }, 1000);        
        })
        .catch(error => {
            console.error("Error al obtener los datos: ", error);
        });

    function printData() {
        var container = document.createElement("div");
        container.classList.add("container");
        document.body.appendChild(container);
        container.innerHTML = "";

        let recObject1 = JSON.parse(localStorage.getItem("object1"));

        recObject1.forEach(function(element) {
            var div = document.createElement("div");
            div.textContent = `${element.ErenJaeger.aparicion}`
            div.style.backgroundColor = "#f0f0f0";
            container.appendChild(div);
        });
    }

    button.addEventListener("click", printData);

}